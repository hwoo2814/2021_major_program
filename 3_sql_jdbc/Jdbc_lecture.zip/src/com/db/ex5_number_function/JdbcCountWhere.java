package com.db.ex5_number_function;

import java.sql.*;

public class JdbcCountWhere {
	
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet=null;

		String driverName = "com.mysql.jdbc.Driver";
		String DBName = "jdbc_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		String sql = "select avg(age) as avg_age from mem where age >=?;";
		int age=20;

		try {
			Class.forName(driverName);
			con = DriverManager.getConnection(dbURL+sslStr, "root", "1111133333");
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, age);
			resultSet = pstmt.executeQuery();

			while (resultSet.next()) 
			{
				System.out.println("avg : "+resultSet.getString("avg_age"));
			}

		}
		catch (ClassNotFoundException e) {
				System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB SQLException fail !!");
			e.printStackTrace();
		
		}
		finally
		{
			if (resultSet != null) {
				try{
					resultSet.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB resultSet close exception !!");	
				}
			}
			if (pstmt != null) {
				try{
					pstmt.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB pstmt close exception !!");	
				}
			}
			if (con != null) {
				try {
					con.close(); 
				}
				catch(SQLException ex) {
					System.out.println("DB connection close exception !!");	
				}
			}
		}
	}
}
