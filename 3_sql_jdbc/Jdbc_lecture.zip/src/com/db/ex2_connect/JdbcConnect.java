package com.db.ex2_connect;

import java.sql.*;

public class JdbcConnect {

	
	public static void main(String[] args) {
		
		Connection conn=null;		
		String driverName = "com.mysql.jdbc.Driver";
		String DBName = "jdbc_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		try {
			
			Class.forName("com.mysql.jdbc.Driver"); 
			System.out.println("JDBC driver load success");

			conn = DriverManager.getConnection(dbURL+sslStr
					, "root","1111133333"); 			
			System.out.println("DB connection success");
		} catch (ClassNotFoundException e) {
			System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB connection fail !!");
		}
		finally
		{
			try
			{
				if(conn!=null) {
					conn.close();			
					System.out.println("DB connection close success");
				}
			}
			catch (SQLException e) {
				System.out.println("DB connection close exception !!");	
			}
		} 

	}

}
