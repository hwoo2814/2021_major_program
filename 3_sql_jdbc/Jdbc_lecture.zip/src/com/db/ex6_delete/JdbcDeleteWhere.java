package com.db.ex6_delete;

import java.sql.*;

public class JdbcDeleteWhere {
	
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int retval=0;
		String id= "apple";
		
		String driverName = "com.mysql.jdbc.Driver";
		String DBName = "jdbc_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		String sql = "delete from user where id=?";
	

		try {
			Class.forName(driverName);
			con = DriverManager.getConnection(dbURL+sslStr, "root", "1111133333");
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,id);
			retval=pstmt.executeUpdate();
	
			System.out.println("delete ����");

		}
		catch (ClassNotFoundException e) {
				System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB SQLException fail !!");
			e.printStackTrace();
		
		}
		finally
		{
			
			if (pstmt != null) {
				try{
					pstmt.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB pstmt close exception !!");	
				}
			}
			if (con != null) {
				try {
					con.close(); 
				}
				catch(SQLException ex) {
					System.out.println("DB connection close exception !!");	
				}
			}
		}
	}
}
