package com.db.ex3_insert;

import java.sql.*;

public class JdbcInsertStatement {
	
	public static void main(String[] args) {
		Connection con = null;
		Statement stmt= null;
		String driverName = "com.mysql.jdbc.Driver";
		String DBName = "jdbc_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		
		try {
			
			Class.forName(driverName);
			con = DriverManager.getConnection(dbURL+sslStr, "root", "1111133333");
			stmt = con.createStatement();
			stmt.executeUpdate("insert into User values ('apple', 'orange', 'melon',20000);");
			stmt.executeUpdate("insert into User values ('chair', 'desk', 'key',1000);");
			stmt.executeUpdate("insert into User values ('deck', 'keyboard', 'mouse',0);");
			System.out.println("3 rows is inserted");

		}
		catch (ClassNotFoundException e) {
				System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB SQLException fail !!");
		
		}
		finally
		{
			if (stmt != null) {
				try{
					stmt.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB stmt close exception !!");	
				}
			}
			if (con != null) {
				try {
					con.close(); 
				}
				catch(SQLException ex) {
					System.out.println("DB connection close exception !!");	
				}
			}
		}
	}



}
