package com.db.ex3_insert;

import java.sql.*;

public class JdbcInsertPreparedStatement {
	
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int retval=0;		
		String driverName = "com.mysql.jdbc.Driver";
		String DBName = "jdbc_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		String sql = "insert into user values (?, ?, ?,?)";	

		try {
			Class.forName(driverName);
			con = DriverManager.getConnection(dbURL+sslStr, "root", "1111133333");
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,"dog");
			pstmt.setString(2,"cat");
			pstmt.setString(3,"lion");
			pstmt.setInt(4,5000);			
			retval=pstmt.executeUpdate();
		
			System.out.println(retval+" rows is inserted");
		}
		catch (ClassNotFoundException e) {
				System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB SQLException fail !!");
		
		}
		finally
		{
			if (pstmt != null) {
				try{
					pstmt.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB stmt close exception !!");	
				}
			}
			if (con != null) {
				try {
					con.close(); 
				}
				catch(SQLException ex) {
					System.out.println("DB connection close exception !!");	
				}
			}
		}
	}
}
