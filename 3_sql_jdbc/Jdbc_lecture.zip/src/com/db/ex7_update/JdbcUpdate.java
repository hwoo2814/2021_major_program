package com.db.ex7_update;

import java.sql.*;

public class JdbcUpdate {
	
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;

		int retval=0;

		String driverName = "com.mysql.jdbc.Driver";
		String DBName = "jdbc_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		String sql = "UPDATE user SET pw=? where id=?";
		String UserId="apple";
		String UserPw="starfruit";		

		try {
			Class.forName(driverName);
			con = DriverManager.getConnection(dbURL+sslStr, "root", "1111133333");
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, UserPw);
			pstmt.setString(2, UserId);
			
			retval = pstmt.executeUpdate();
			System.out.println(retval+" is updated");

		}
		catch (ClassNotFoundException e) {
				System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB SQLException fail !!");
			e.printStackTrace();
		
		}
		finally
		{

			if (pstmt != null) {
				try{
					pstmt.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB pstmt close exception !!");	
				}
			}
			if (con != null) {
				try {
					con.close(); 
				}
				catch(SQLException ex) {
					System.out.println("DB connection close exception !!");	
				}
			}
		}
	}
}
