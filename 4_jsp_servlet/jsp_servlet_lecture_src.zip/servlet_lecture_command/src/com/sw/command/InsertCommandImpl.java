package com.sw.command;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




public class InsertCommandImpl implements Service {

	@Override
	public int execute(MemberDto mdto) throws ServletException, IOException{
	
		MemberDao mdao = new MemberDaoImpl();	
		int retVal=mdao.insertMember(mdto);
		return retVal;
	}
}
