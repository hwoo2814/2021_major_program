package com.sw.el;

public class Member {
	String name;
	String num;
}
