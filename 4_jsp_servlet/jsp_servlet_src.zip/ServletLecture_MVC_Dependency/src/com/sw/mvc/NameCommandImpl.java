package com.sw.mvc;





public class NameCommandImpl implements Service {
	
	@Override
	public MemberDto execute(MemberDto mdto) {
		
		MemberDao dao = new MemberDaoImpl();
		String name = mdto.getName();
		return dao.getMemberByName(name);
		
	}
}
