package com.sw.mvc;


public class IdCommandImpl implements Service {

	@Override
	public MemberDto execute( MemberDto mdto) {
		
		MemberDao dao = new MemberDaoImpl();
		String id = mdto.getId();
		System.out.println("IdCommand::execute() id : "+id);
		return dao.getMemberById(id);
		
	}
}
