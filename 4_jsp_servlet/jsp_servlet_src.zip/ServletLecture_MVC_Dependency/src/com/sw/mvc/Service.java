package com.sw.mvc;




public interface Service {
	public MemberDto execute(MemberDto mdto);
}
