package com.sw.mvc;



public class EmailCommandImpl implements Service {
	
	@Override
	public MemberDto execute(MemberDto mdto) {
		MemberDao dao = new MemberDaoImpl();
		String email = mdto.geteMail();
		return dao.getMemberByEMail(email);
	}
}
