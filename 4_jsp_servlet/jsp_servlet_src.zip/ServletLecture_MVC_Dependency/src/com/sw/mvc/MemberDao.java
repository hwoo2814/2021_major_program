package com.sw.mvc;

import java.sql.*;

public interface MemberDao {
	public MemberDto getMemberById(String id);
	public MemberDto getMemberByName(String name);
	public MemberDto getMemberByEMail(String eMail);
	public Connection getConnection();

}
