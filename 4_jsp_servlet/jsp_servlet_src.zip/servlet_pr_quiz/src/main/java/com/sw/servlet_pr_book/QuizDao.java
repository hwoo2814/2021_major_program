package com.sw.servlet_pr_book;
import java.sql.*;


public interface QuizDao {
	
	public int insert(QuizDto mdto);
	public String quiz(String id);
	public Connection getConnection() ;
	public void closeConnection(ResultSet set, PreparedStatement pstmt, Connection connection);

}
