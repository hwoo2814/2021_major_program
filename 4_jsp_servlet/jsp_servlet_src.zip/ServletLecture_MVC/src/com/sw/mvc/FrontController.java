package com.sw.mvc;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;






/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);
	}
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("actionDo");
		
		request.setCharacterEncoding("EUC-KR");
		
		String viewPage = null;
		Service command = null;
		MemberDto dtos = null;
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		MemberDto mdto = new MemberDto();
		
		System.out.println("actionDo - "+com);
		if(com.equals("/id.do")) {
			command = new IdCommandImpl();
			String id = request.getParameter("id");
			mdto.setId(id);
			dtos = command.execute(request, response, mdto);
			viewPage = "view_memberInfo.jsp";
		} else if(com.equals("/name.do")) {
			command = new NameCommandImpl();
			String name = request.getParameter("name");
			mdto.setName(name);
			dtos = command.execute(request, response, mdto );
			viewPage = "view_memberInfo.jsp";
		} else if(com.equals("/email.do")){
			command = new EmailCommandImpl();
			String email = request.getParameter("email");
			mdto.seteMail(email);
			dtos = command.execute(request, response, mdto );
			viewPage = "view_memberInfo.jsp";
		}
		HttpSession session = request.getSession();
		MemberDto.printDto(dtos);
		session.setAttribute("mInfo", dtos);
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
	} 
	

}
