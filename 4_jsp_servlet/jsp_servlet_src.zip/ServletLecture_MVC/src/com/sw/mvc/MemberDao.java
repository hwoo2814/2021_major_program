package com.sw.mvc;

import java.sql.Connection;

public interface MemberDao {
	public MemberDto getMemberById(String id);
	public MemberDto getMemberByName(String name);
	public MemberDto getMemberByEMail(String eMail);
	public Connection getConnection();

}
