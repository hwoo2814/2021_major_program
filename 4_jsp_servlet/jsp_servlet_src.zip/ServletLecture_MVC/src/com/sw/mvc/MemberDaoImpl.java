package com.sw.mvc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class MemberDaoImpl implements MemberDao{
		
	public MemberDto getMemberById(String id) {
		System.out.println("MemberDao::getMemberById");
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		String query = "select * from members where id = ?";
		MemberDto dto = new MemberDto();
		
		try {
			connection = getConnection();
			System.out.println("MemberDao::connected");
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, id);
			set = pstmt.executeQuery();
			
			while(set.next()) { 
				

				dto.setId(set.getString("id"));
				dto.setPw(set.getString("pw"));
				dto.setName(set.getString("name"));
				dto.seteMail(set.getString("eMail"));
				dto.setRegDate(set.getTimestamp("reg_date"));
				dto.setAddress(set.getString("address"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception : getMemberById()");
		} finally {
			closeConnection(set,pstmt,connection);
		}
		
		return dto;
		
	}
	
	public MemberDto getMemberByName(String name) {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		String query = "select * from members where name = ?";
		MemberDto dto = new MemberDto();
		
		try {
			connection = getConnection();
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, name);
			set = pstmt.executeQuery();
			
			while(set.next()) {				
				dto.setId(set.getString("id"));
				dto.setPw(set.getString("pw"));
				dto.setName(set.getString("name"));
				dto.seteMail(set.getString("eMail"));
				dto.setRegDate(set.getTimestamp("reg_date"));
				dto.setAddress(set.getString("address"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception : getMemberByName()");
		} finally {
			closeConnection(set,pstmt,connection);		
		}
		
		return dto;
		
	}
	public MemberDto getMemberByEMail(String eMail) {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		String query = "select * from members where eMail = ?";
		MemberDto dto = new MemberDto();
		
		try {
			connection = getConnection();
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, eMail);
			set = pstmt.executeQuery();
			
			while(set.next()) {
				dto.setId(set.getString("id"));
				dto.setPw(set.getString("pw"));
				dto.setName(set.getString("name"));
				dto.seteMail(set.getString("eMail"));
				dto.setRegDate(set.getTimestamp("reg_date"));
				dto.setAddress(set.getString("address"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception : getMemberByEMail()");
		} finally {
			closeConnection(set,pstmt,connection);
		}
		
		return dto;
		
	}
	
	public Connection getConnection() {
		
		Connection conn=null;		
		String DBName = "jsp_servlet_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		try {
			
			Class.forName("com.mysql.jdbc.Driver"); 
			System.out.println("JDBC driver load success");

			conn = DriverManager.getConnection(dbURL+sslStr
					, "root","1111133333"); 			
			System.out.println("DB connection success");
		} catch (ClassNotFoundException e) {
			System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB connection fail !!");
		}
		
		return conn;
	}
	public void closeConnection(ResultSet set, PreparedStatement pstmt, Connection connection) {
		if(set!=null)
		{
			try {
			set.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}	
		if(pstmt!=null)
		{
			try {
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		if(connection!=null)
		{
			try {
				connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	
}
