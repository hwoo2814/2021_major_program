package com.sw.mvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




public class IdCommandImpl implements Service {

	@Override
	public MemberDto execute(HttpServletRequest request, HttpServletResponse response, MemberDto mdto) {
		
		MemberDao dao = new MemberDaoImpl();
		String id = request.getParameter("id");
		System.out.println("IdCommand::execute() id : "+id);
		return dao.getMemberById(id);
		
	}
}
