package com.sw.mvc;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




public class EmailCommandImpl implements Service {
	
	@Override
	public MemberDto execute(HttpServletRequest request, HttpServletResponse response, MemberDto mdto) {
		MemberDao dao = new MemberDaoImpl();
		String email = mdto.geteMail();
		return dao.getMemberByEMail(email);
	}
}
