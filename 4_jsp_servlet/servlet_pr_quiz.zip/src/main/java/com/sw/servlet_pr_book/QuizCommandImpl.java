package com.sw.servlet_pr_book;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




public class QuizCommandImpl implements Service {

	@Override
	public int execute(QuizDto dto) throws ServletException, IOException{
		
		String id=dto.getId();
		String answer=dto.getAnswer();
//		System.out.println(answer);
		QuizDao mdao = new QuizDaoImpl();
		String dbAnswer=mdao.quiz(id);
//		System.out.println(dbAnswer);
		if(answer.equals(dbAnswer)){
			return 1;
		}
		else {
			return -1;
		}		
	}
}
