package com.sw.servlet_pr_book;

import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;

public class QuizFakeDaoImpl implements QuizDao{
	ArrayList<QuizDto> dbData;
	public QuizFakeDaoImpl() {
		dbData = new ArrayList<QuizDto>();
		QuizDto data = new QuizDto();
		data.setId("1");
		data.setQuestion("book name?");
		data.setAnswer("history");
		dbData.add(data);
		data = new QuizDto();
		data.setId("2");
		data.setQuestion("favorite fruit");
		data.setAnswer("banana");
		dbData.add(data);
		data = new QuizDto();
		data.setId("3");
		data.setQuestion("home town?");
		data.setAnswer("LA");
		dbData.add(data);
		
	}
	public int insert(QuizDto dto)
	{
		dbData.add(dto);
		return 1;
	}
	
	public String quiz(String id)
	{
		String answer=null;
		Iterator iterator = dbData.iterator();

		while(iterator.hasNext()){

			QuizDto data = (QuizDto)iterator.next();
			if(data.getId().equals(id)) {
				answer=data.getAnswer();
			}

		}
		return answer;
	}

	public Connection getConnection() {
		
		Connection conn=null;		
		
		return conn;
	}
	public void closeConnection(ResultSet set, PreparedStatement pstmt, Connection connection) {
		
	}

}
