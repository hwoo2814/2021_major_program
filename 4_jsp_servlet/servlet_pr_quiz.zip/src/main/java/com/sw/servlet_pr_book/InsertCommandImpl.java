package com.sw.servlet_pr_book;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




public class InsertCommandImpl implements Service {

	@Override
	public int execute(QuizDto dto) throws ServletException, IOException{
	
		QuizDao dao = new QuizDaoImpl();	
		int retVal=dao.insert(dto);
		return retVal;
	}
}
