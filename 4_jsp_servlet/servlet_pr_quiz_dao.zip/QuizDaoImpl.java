package com.sw.servlet_pr_book;

import java.sql.*;

public class QuizDaoImpl implements QuizDao{
	public int insert(QuizDto dto)
	{
		int ret=0;
		String sql = "insert into quiz values (?, ?, ?)";
		Connection conn=null;
		PreparedStatement pstmt = null;
		
		try {
			conn=getConnection();
			System.out.println("connection ok");
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,dto.getId());
			pstmt.setString(2,dto.getQuestion());
			pstmt.setString(3,dto.getAnswer());			
			pstmt.executeUpdate();	
			System.out.println("insert ok");
			ret=1;
		}catch (SQLException e){
			ret=-1;
			System.out.println("access error.");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}finally
		{
			 closeConnection(null,pstmt,conn);
		} 
		return ret;
	}
	
	public String quiz(String id)
	{
		String answer=null;
		Connection conn = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String answerDb=null;
		try{
		 
	        String sql="select answer from quiz where id = ?";
	        conn=getConnection(); 
			System.out.println("connection ok");
	        pstmt = conn.prepareStatement(sql);
	        pstmt.setString(1, id);
	        rs= pstmt.executeQuery();
	    	
    		while (rs.next()) 
    		{
    			answerDb = rs.getString("answer");
    			System.out.println("answer : "+answerDb);
			}
    		answer=answerDb;
	    	
		 }catch (SQLException e){
			System.out.println("SQLException error.");
			e.printStackTrace();
		}finally{
			closeConnection(rs,pstmt,conn);       
		}
		return answer;
	}

	public Connection getConnection() {
		
		Connection conn=null;		
		String DBName = "jsp_servlet_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		try {
			
			Class.forName("com.mysql.jdbc.Driver"); 
			System.out.println("JDBC driver load success");

			conn = DriverManager.getConnection(dbURL+sslStr
					, "root","1111133333"); 			
			System.out.println("DB connection success");
		} catch (ClassNotFoundException e) {
			System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB connection fail !!");
		}
		
		return conn;
	}
	public void closeConnection(ResultSet set, PreparedStatement pstmt, Connection connection) {
		if(set!=null)
		{
			try {
			set.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}	
		if(pstmt!=null)
		{
			try {
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		if(connection!=null)
		{
			try {
				connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

}
